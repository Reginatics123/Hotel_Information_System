-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2019 at 05:49 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `activity`
--
CREATE DATABASE IF NOT EXISTS `activity` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `activity`;

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `id` int(11) NOT NULL,
  `Firstname` varchar(45) NOT NULL,
  `Lastname` varchar(45) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `MobileNo` varchar(45) NOT NULL,
  `Nationality` varchar(45) NOT NULL,
  `Gender` varchar(45) NOT NULL,
  `CheckInDate` varchar(45) NOT NULL,
  `DateOfOut` varchar(45) NOT NULL,
  `BedType` varchar(45) NOT NULL,
  `RoomNo` varchar(45) NOT NULL,
  `RoomKey` varchar(45) NOT NULL,
  `Rate` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`id`, `Firstname`, `Lastname`, `Address`, `MobileNo`, `Nationality`, `Gender`, `CheckInDate`, `DateOfOut`, `BedType`, `RoomNo`, `RoomKey`, `Rate`) VALUES
(1, 'Erica', 'Mejos', 'Riverside', '245678456', 'Filipino', 'Female', 'May 21, 2019', 'May 28, 2019', 'Single Bed', '105', 'AC', '10000'),
(2, 'Jojeanne', 'Tubang', 'Daticor', '12345678901', 'Filipino', 'Male ', 'July   5 ,   2019', 'July   28, 2019', 'Single Bed', '609', 'ac', '2000'),
(3, 'Rachele Ann', 'Ligad', 'SudLon', '12345678923', 'Filipino', 'Female', 'June  6,  2019', 'June  27, 2019', 'Single Bed', '109', 'AC', '3000'),
(5, 'Regin', 'Dagusing', 'Matiao', '12345678912', 'British', 'Female', 'May 28, 2019', 'May 30, 2019', 'Single Bed', '105', 'ac', '2000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `information`
--
ALTER TABLE `information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
